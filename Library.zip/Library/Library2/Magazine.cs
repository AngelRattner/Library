﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library2
{
   public  class Magazin : Writes
    {
        public Magazin(string name, string publisher, DateTimeOffset publish_date, float price, string geners) : base(name, publisher, publish_date, price, geners)
        { }

    }
}
