﻿using System;
using System.Collections.Generic;

namespace Library2
{
    public class ItemCollections
    {
        public static List<Writes> Items { get; set; }
        
        public ItemCollections()
        {
            if(Items==null)Items = new List<Writes>();
        }
        public void AddItem(Writes a)
        {
            if (Items.Contains(a)) throw new Exception("this Writes already in the item collection");
            Items.Add(a);
        }
        public void RemoveItem(Writes a)
        {
            if (!Items.Contains(a)) throw new Exception("this Writes already  out of the item collection");
            else Items.Remove(a);
        }
        public static List<Writes> FindbyName(string name)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._name == name)
                {
                    tmp.Add(Items[i]);
                }
            }
            return tmp;
        }
        public static List<Writes> FindbyGeners(string geners)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._geners == geners)
                {
                    tmp.Add(Items[i]);
                }
            }
            return tmp;
        }
        public static List<Writes> FindbyPrice(float price)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._price == price)

                {
                    tmp.Add(Items[i]);
                }

            }
            return tmp;
        }
        public static List<Writes> FindbyPublisher(string publisher)
        {
            List<Writes> tmp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i]._publisher == publisher)
                    
                    {
                    tmp.Add(Items[i]);
                }

            }
            return tmp;
        }
        public static List<Writes> FindBYAuther(string auther)
        {
            List<Writes> temp = new List<Writes>();
            for (int i = 0; i < Items.Count; i++)
            {
               Book tmp = (Book)Items[i];
                if ((tmp._author == auther))
                {
                    temp.Add(Items[i]);
                }

            }
            return temp;
        }
    }

}
