﻿using Library2;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.ServiceModel.Channels;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Library
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public static string name,passowrd;
        public ItemCollections lab = new ItemCollections();
        public static bool librarian = false;
        public MainPage()
        {
            this.InitializeComponent();
            Book a = new Book("a"," b", "c", default, 2, "e");
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (namebox.Text == "Angel" && passbox.Text == "123") librarian = true; //ck if its labr
            else if (namebox.Text == "" && passbox.Text == "") err.Visibility = Visibility.Visible; //ck that u put something
            else librarian = false; 
            name = namebox.Text; //get the user name to say who took it
            passowrd = passbox.Text; 
            Frame.Navigate(typeof(Library));
           
        }

    }
}
