﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Library2;
using System.Collections.ObjectModel;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Library
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Collection : Page
    {
        public static List<Writes> show =new List<Writes>();
        ObservableCollection<string> option = new ObservableCollection<string>();
        public Collection()
        {
            this.InitializeComponent();
            option.Add("name");
            option.Add("publisher");
            option.Add("geners");
            option.Add("author");
            Button[] btn = new Button[Library2.ItemCollections.Items.Count];
            bool NeedToReturn = false;
            for (int i = 0; i < Library2.ItemCollections.Items.Count; i++)
            {
                if (Library2.ItemCollections.Items[i]._rentBy == MainPage.name) NeedToReturn = true;
            }
            if (NeedToReturn)//return the book first
            {
                for (int i = 0; i < Library2.ItemCollections.Items.Count; i++) //if user alredy rent a book he must return it first
                {
                    if (Library2.ItemCollections.Items[i]._rentBy == MainPage.name)
                    {
                        isremove.IsEnabled = false;
                        isedit.IsEnabled = false;
                        rent.IsEnabled = false;
                        _return.IsChecked = true;
                        int index = i;
                        TextBlock info = new TextBlock();
                        bord.Children.Add(info);
                        info.Width = 100;
                        info.Height = 100;
                        Canvas.SetLeft(info, 300);
                        Canvas.SetTop(info, 700);
                        info.Text = "you must return the book you rented befor you take another one,\n Thank you!";
                        btn[i] = new Button();
                        bord.Children.Add(btn[i]);
                        btn[i].Width = 750;
                        btn[i].Height = 200;
                        Canvas.SetLeft(btn[i], 50);
                        Canvas.SetTop(btn[i], i * 200);
                        btn[i].Content = Library2.ItemCollections.Items[i];
                        btn[i].Click += (s, e) =>
                        {
                            //int index = (int)(s as Button).Tag;
                            Library2.ItemCollections.Items[index].isrented = false;
                            Library2.ItemCollections.Items[index]._rentBy = "";
                            Frame.Navigate(typeof(Library));
                        };
                    }
                }
            }//return the book
            else
            {
                for (int i = 0; i < Library2.ItemCollections.Items.Count; i++)
                {
                    btn[i] = new Button();
                    btn[i].Tag = i;
                    bord.Children.Add(btn[i]);
                    btn[i].Width = 700;
                    btn[i].Height = 50;
                    Canvas.SetLeft(btn[i], 30);
                    Canvas.SetTop(btn[i], i * 50);
                    btn[i].Content = Library2.ItemCollections.Items[i];
                    btn[i].Click += (s, e) =>
                    {
                        if (isremove.IsChecked == true)
                        {
                            int index = (int)(s as Button).Tag;
                            Library2.ItemCollections.Items.RemoveAt(index);
                            Frame.Navigate(typeof(Library));
                        }
                        else if (isedit.IsChecked == true)
                        {
                            int index = (int)(s as Button).Tag;
                            if (ItemCollections.Items[index] is Book)
                            {
                                SAVE.Visibility = Visibility.Visible;
                                Book tmp = (Book)ItemCollections.Items[index];
                                TextBox a = new TextBox();
                                a.Text = ItemCollections.Items[index]._name;
                                TextBox b = new TextBox();
                                b.Text = ItemCollections.Items[index]._publisher;
                                DatePicker c = new DatePicker();
                                c.Date = ItemCollections.Items[index]._publish_date;
                                TextBox d = new TextBox();
                                d.Text = ItemCollections.Items[index]._geners;
                                TextBox t = new TextBox();
                                t.Text = ItemCollections.Items[index]._price.ToString();
                                TextBox f = new TextBox();
                                f.Text = tmp._author;
                                bord.Children.Add(a);
                                bord.Children.Add(b);
                                bord.Children.Add(c);
                                bord.Children.Add(d);
                                bord.Children.Add(t);
                                bord.Children.Add(f);
                                Canvas.SetLeft(a, 900);
                                Canvas.SetLeft(b, 900);
                                Canvas.SetLeft(c, 900);
                                Canvas.SetLeft(d, 900);
                                Canvas.SetLeft(t, 900);
                                Canvas.SetLeft(f, 900);
                                Canvas.SetTop(a, 200);
                                Canvas.SetTop(b, 300);
                                Canvas.SetTop(c, 400);
                                Canvas.SetTop(d, 500);
                                Canvas.SetTop(t, 600);
                                Canvas.SetTop(f, 700);
                                SAVE.Click += (p, q) =>
                                {
                                    SAVE.Visibility = Visibility.Collapsed;
                                    ItemCollections.Items[index]._name = a.Text;
                                    ItemCollections.Items[index]._publisher = b.Text;
                                    ItemCollections.Items[index]._publish_date = c.Date;
                                    ItemCollections.Items[index]._geners = d.Text;
                                    ItemCollections.Items[index]._price = float.Parse(t.Text);
                                    tmp = (Book)ItemCollections.Items[index];
                                    tmp._author = f.Text;
                                    ItemCollections.Items[index] = tmp;
                                    Frame.Navigate(typeof(Library));
                                };

                            }
                            else
                            {
                                SAVE.Visibility = Visibility.Visible;
                                TextBox a = new TextBox();
                                a.Text = ItemCollections.Items[index]._name;
                                TextBox b = new TextBox();
                                b.Text = ItemCollections.Items[index]._publisher;
                                DatePicker c = new DatePicker();
                                c.Date = ItemCollections.Items[index]._publish_date;
                                TextBox d = new TextBox();
                                d.Text = ItemCollections.Items[index]._geners;
                                TextBox t = new TextBox();
                                t.Text = ItemCollections.Items[index]._price.ToString();
                                TextBox f = new TextBox();
                                bord.Children.Add(a);
                                bord.Children.Add(b);
                                bord.Children.Add(c);
                                bord.Children.Add(d);
                                bord.Children.Add(t);
                                Canvas.SetLeft(a, 900);
                                Canvas.SetLeft(b, 900);
                                Canvas.SetLeft(c, 900);
                                Canvas.SetLeft(d, 900);
                                Canvas.SetLeft(t, 900);
                                Canvas.SetTop(a, 200);
                                Canvas.SetTop(b, 300);
                                Canvas.SetTop(c, 400);
                                Canvas.SetTop(d, 500);
                                Canvas.SetTop(t, 600);
                                SAVE.Click += (p, q) =>
                                {
                                    SAVE.Visibility = Visibility.Collapsed;
                                    ItemCollections.Items[index]._name = a.Text;
                                    ItemCollections.Items[index]._publisher = b.Text;
                                    ItemCollections.Items[index]._publish_date = c.Date;
                                    ItemCollections.Items[index]._geners = d.Text;
                                    ItemCollections.Items[index]._price = float.Parse(t.Text);
                                    Frame.Navigate(typeof(Library));
                                };
                            }
                        }
                        else if (rent.IsChecked == true)
                        {
                            int index = (int)(s as Button).Tag;
                            if (ItemCollections.Items[index].isrented == true)
                            {
                                TextBlock taken = new TextBlock();
                                taken.Text = "sorry that book is alrady rented by someone else";
                                bord.Children.Add(taken);
                                Canvas.SetLeft(taken, 800);
                                Canvas.SetTop(taken, 500);
                            }
                            else
                            {
                            //DateTime.Now
                            ItemCollections.Items[index].isrented = true;
                                ItemCollections.Items[index].rent_date = DateTime.Now;//set time of rent
                            ItemCollections.Items[index]._rentBy = MainPage.name; //set who took it
                            Frame.Navigate(typeof(Library));
                            }
                        }
                        else if (_return.IsChecked == true)
                        {
                            int index = (int)(s as Button).Tag;
                            if (ItemCollections.Items[index]._rentBy == MainPage.name)
                            {
                                ItemCollections.Items[index].isrented = false;
                                Frame.Navigate(typeof(Library));
                            }
                            else
                            {
                                TextBlock not_you = new TextBlock();
                                not_you.Text = "your user didnt rent the book you cant return it";
                                bord.Children.Add(not_you);
                                Canvas.SetLeft(not_you, 700);
                                Canvas.SetTop(not_you, 500);
                            }
                        }

                    };
                }
                if (MainPage.librarian == true)
                {
                    isedit.IsEnabled = true;
                    isremove.IsEnabled = true;
                }
                else
                {
                    isedit.IsEnabled = false;
                    isremove.IsEnabled = false;
                }
            }//new user
        }


        private void btnback_Click(object sender, RoutedEventArgs e)//go back
        {
            Frame.Navigate(typeof(Library));
        }

        private void Button_Click(object sender, RoutedEventArgs e)//search a book/mag
        {
            Book tmp = new Book("", "", "", default, 0, "");
            Magazin tem = new Magazin("", "", default, 0, "");
            List<Button> a = new List<Button>();
            if (option.Contains("name")) show = ItemCollections.FindbyName(bytxt.Text);
            else if (option.Contains("publisher")) show = ItemCollections.FindbyPublisher(bytxt.Text);
            else if (option.Contains("geners")) show = ItemCollections.FindbyGeners(bytxt.Text);
            else if (option.Contains("author")) show = ItemCollections.FindBYAuther(bytxt.Text);
            if (show.Count==0) not_fond.Visibility = Visibility.Visible;
            else Frame.Navigate(typeof(Serc));
        }
    }
}
