﻿using Library2;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Library
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Library : Page
    {
        public int cont = 0;
        public int book = 0;
        public int late = 0;
        public int mag = 0;
        public Library()
        {
            this.InitializeComponent();
            if (MainPage.librarian == true)
            {
                add.IsEnabled = true;
                dis.IsEnabled = true;
            }
            else
            {
                add.IsEnabled = false;
                dis.IsEnabled = false;
            }
        }

        private void add_Click(object sender, RoutedEventArgs e)//add book/mag
        {
            Frame.Navigate(typeof(AddItem));
        }
        
        private void show_Click(object sender, RoutedEventArgs e)//show all the books and able to rent one
        {
            Frame.Navigate(typeof(Collection));
        }

        private void _out_Click(object sender, RoutedEventArgs e) //log out
        {
            Frame.Navigate(typeof(MainPage));
        }

        private void rep_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < Library2.ItemCollections.Items.Count; i++)
            {
                if (Library2.ItemCollections.Items[i] is Book) book++;
                else mag++;
                if (Library2.ItemCollections.Items[i].isrented) cont++;
                if ((Library2.ItemCollections.Items[i].rent_date- DateTime.Now).TotalDays > 14) late++;
            }
            TextBlock rep = new TextBlock();
            bord.Children.Add(rep);
            Canvas.SetLeft(rep, 830);
            Canvas.SetTop(rep, 250);
            rep.Height = 300;
            rep.Width = 200;
            rep.Text = $"we have {book} books \n we have {mag} magazine \n {cont} is rented out of {Library2.ItemCollections.Items.Count} items \n{late} customer are late to return there books/magazins";
        }

        private void dis_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Discount));
        }
    }
}
