﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Library2;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Library
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AddItem : Page
    {
        public AddItem()
        {
            this.InitializeComponent();
            pricetxt.BeforeTextChanging += (s, args) => { args.Cancel = args.NewText.Any(c => !char.IsDigit(c)); };//only numbers
        }
        
        private void Addbtn_Click(object sender, RoutedEventArgs e)
        {
            if (isbook.IsChecked == true)
            {
                if (nametxt.Text != "" && authortxt.Text != "" && pubtxt.Text != "" && datepic.SelectedDate!=null && gentxt.Text != "" && pricetxt.Text != "")
                {
                    float tmp,tmp2;
                    float.TryParse(pricetxt.Text, out tmp2);
                    Book a = new Book(nametxt.Text, authortxt.Text, pubtxt.Text,datepic.SelectedDate.Value,tmp2 , gentxt.Text);
                    Library2.ItemCollections.Items.Add(a);
                    Frame.Navigate(typeof(Library));
                }
                else error.Visibility = Visibility.Visible;
            }
            else
            {
                if (nametxt.Text != ""  && pubtxt.Text != "" && datepic.SelectedDate != null && gentxt.Text != "" && pricetxt.Text != "")
                {
                    float tmp, tmp2;
                    float.TryParse(pricetxt.Text, out tmp2);
                    Magazin  a = new Magazin(nametxt.Text, pubtxt.Text, datepic.SelectedDate.Value, tmp2, gentxt.Text);
                    Library2.ItemCollections.Items.Add(a);
                    Frame.Navigate(typeof(Library));
                }
                else error.Visibility = Visibility.Visible;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Library));
        }

        private void isbook_Checked(object sender, RoutedEventArgs e)
        {
            authortxt.Visibility = Visibility.Visible;
        }

        private void isbook_Unchecked(object sender, RoutedEventArgs e)
        {
            authortxt.Visibility = Visibility.Collapsed;
        }

        private void pricetxt_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
